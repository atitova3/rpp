#ifndef ROUTE_H
#define ROUTE_H
#include <QString>
#include <QTime>

class Route
{
public:
    int num;
    QString estop;
    QTime time;
    long int price;
    Route();
};

#endif // ROUTE_H
