#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <route.h>
#include <vector>
#include <mymodel.h>
using namespace std;

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    vector<Route> list;
    Q_OBJECT
    MyModel* mod;

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_add_clicked();

private slots:
    void on_load_clicked();

    void on_delete_2_clicked();

    void on_save_clicked();

    void on_pushButton_5_clicked();

    void on_table_clicked(const QModelIndex &index);

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
