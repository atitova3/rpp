#include "widget.h"
#include "ui_widget.h"
#include <QFile>
#include <QDebug>
#include <vector>
#include <mymodel.h>
using namespace std;

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->estopRoute->setEditable(true);

    ui->estopRoute->clear();
    for (int i = 0; i < this->list.size(); i++)
    {
        ui->estopRoute->addItem(this->list.at(i).estop);
    }
    //ui->
    //ui->estopRoute->lineEdit()->set//
    mod = new MyModel(list);
    ui->table->setModel(mod);
    //ui->table->setSelectionBehavior(QAbstractItemModel::Row());
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_load_clicked()
{
    QFile file ("C:/Users/asus/Desktop/rpp3.txt");
    QByteArray reading;
    std::vector<std::vector<QString>> stroki;//в этом векторе хранятся слова
    QString line;
    if (!file.open(QIODevice::ReadOnly))
    {
        qDebug() << "Файл не открыт";
    }
    else
    {
        qDebug() << "Файл открыта";
        QTextStream textStream(&file);
        QString line;
        QString text;
        int chet;
        int kov = 0; // пока у нас нет строчки 41
        int zap = 0; // пока у нас нет строчки 42
        int flag;//отмечаем после " чтобы проверить на дальнейшие шаги
        std::vector<QString> one_str;
        for (int j = 0; !textStream.atEnd(); j++)
        {
            line = textStream.readLine();
            chet = 0;

            for (int i = 0; i < line.size(); i++)
            {
                if ((line[i] == ',')&&((kov == 0)||(kov == 2)))//
                {
                    qDebug() << text;//
                    one_str.push_back(text);//stroki.at(chet).push_back(text);//закидываем в вектор строки ОДНОЙ
                    text ="";
                    zap = 0;
                    kov = 0;
                    flag = 0;//
                }
                else
                {

                    if ((line[i] == '"')&&(flag == 1))
                    {
                        if (text != "\ n")//костыль для удаления \" у \n\"   ///////////////////////////////
                        {
                            text += line[i]; qDebug() << "+" << line[i];//
                        }
                        kov --;
                        flag = 0;//
                    }
                    else
                    {

                        if (line[i] == '"')
                        {
                            kov ++;
                            flag = 1; //
                        }
                        else
                        {
                            if((line[i] == '\n')||(line[i] == '\0'))// НЕ добавила "&&(kov == 0"
                            {
                            }
                            else
                            {
                                text += line[i]; //qDebug() << "+" << line[i];//
                                flag = 0;
                            }
                        }
                    }
                }

            }
            //кривой костыль для того, чтобы переход
            if (kov != 0)
            {
                text += "\n";
                kov = 1;//???
            }

            if ((!textStream.atEnd())&&(kov == 0))
            {
                stroki.push_back(one_str);//вектор добовляет строку
                one_str.clear();//очистка
            }
          }
          one_str.push_back(text);//stroki.at(chet).push_back(text);//закидываем в вектор строки ОДНОЙ
          stroki.push_back(one_str);//вектор добовляет строку
          file.close();
        }
    /**/
        for (int i = 0; i < stroki.size(); i++)
        {
            Route way;
            way.num = 0;
            QString text = stroki.at(i).at(0);
            for (int a = 0; a < text.size(); a++)
            {
                way.num = way.num*10 + text.at(a).digitValue();
            }
            //way.num = 0;//stroki.at(i).at(0).digitValue();
            way.estop = stroki.at(i).at(1);
            way.time = QTime::fromString(stroki.at(i).at(2));
            way.price = 0;
            text = stroki.at(i).at(3);
            for (int a = 0; a < text.size(); a++)
            {
                way.price = way.price*10 + text.at(a).digitValue();
            }
            list.push_back(way);
        }
/**/
    ////////////////////////////////
    mod = new MyModel(list);
    ui->table->setModel(mod);
    ////////////////////////////////
    qDebug() << "END";
    /**/
    ui->estopRoute->clear();
    for (int i = 0; i < this->list.size(); i++)
    {
        ui->estopRoute->addItem(this->list.at(i).estop);
    }
}

void Widget::on_add_clicked()
{
    int flN = 0;
    int num = 0;
    if (ui->numRoute->displayText().size() > 0)
    {
        int i =0;
        QString text1 = ui->numRoute->displayText();
        while ((i < text1.size())&&(flN == 0))
        {
            if ((text1.at(i) >= "0")&&(text1.at(i) <= "9"))
            {
                num = num * 10 + text1.at(i).digitValue();
                i++;
            }
            else
            {
                flN = 1;
            }
            qDebug() << num;
        }
    }

    int flP = 0;
    int price = 0;
    if (ui->priceRoute->displayText().size() > 0)
    {
        int i =0;
        QString text2 = ui->priceRoute->displayText();
        while ((i < text2.size())&&(flP == 0))
        {
            if ((text2.at(i) >= "0")&&(text2.at(i) <= "9"))
            {
                price = price * 10 + text2.at(i).digitValue();
                i++;
            }
            else
            {
                flP = 1;
            }
        }
    }

    //qDebug() << ui->timeRoute->dateTime().time();

    if ((flN == 0)&&(flP == 0)&&(ui->estopRoute->currentText().size() != 0))
    {
        Route way;
        way.num = num;
        way.estop = ui->estopRoute->currentText();
        way.time = ui->timeRoute->dateTime().time();
        //qDebug() << "time " << ui->timeRoute->dateTime().time();
        way.price = price;
        list.push_back(way);
        if (list.size() != 0)
        {
            qDebug() << "ONE";
        }
        ////////////////////////////////
        mod = new MyModel(list);
        mod->setHeaderData(0, Qt::Horizontal, tr("Номер маршрута"));
        mod->setHeaderData(1, Qt::Horizontal, tr("Конечная остановка"));
        mod->setHeaderData(2, Qt::Horizontal, tr("Время в пути"));
        mod->setHeaderData(3, Qt::Horizontal, tr("Стоимость билета"));
        ui->table->setModel(mod);
        ////////////////////////////////
    }
    else
    {
        //с ошибкой заполнил
    }
    ui->estopRoute->clear();
    for (int i = 0; i < this->list.size(); i++)
    {
        ui->estopRoute->addItem(this->list.at(i).estop);
    }
    ui->numRoute->clear();
    ui->estopRoute->clearEditText();
    ui->timeRoute->clearMaximumTime();
    ui->timeRoute->clearMinimumTime();
    ui->priceRoute->clear();
}

void Widget::on_delete_2_clicked()
{
    int ind = ui->table->selectionModel()->selectedRows().first().row();
    list.erase(list.begin()+ind);
    mod = new MyModel(list);
    ui->table->setModel(mod);
}

void Widget::on_save_clicked()
{
    QFile file ("C:/Users/asus/Desktop/rpp3.txt");
    QString text;
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        qDebug() << "Ошибка при открытии файла";
    }
    else
    {
        int num;
        QTextStream stream(&file);
        for(int s = 0; s < this->list.size(); s++)
        {
            text += '"';
            text+= QString::number(this->list.at(s).num);
            text += '"';
            text += ',';
            //qDebug() << "D NTRCT <" << this->list.at(s).num << ">";
            text += '"';
            text += this->list.at(s).estop;
            text += '"';
            text += ',';
            text += '"';
            text += (this->list.at(s).time).toString("hh:mm");
            text += '"';
            text += ',';
            text += '"';
            text += QString::number(this->list.at(s).price);
            text += '"';
            text += ',';
            text += "\0\n";
        }
        qDebug() << text;
        stream << text;
        file.close();
    }
}

void Widget::on_pushButton_5_clicked()
{
    close();
}
