#include "mymodel.h"
#include <route.h>
#include <vector>
using namespace std;

MyModel::MyModel(vector<Route> line, QObject *parent)
    : QAbstractTableModel(parent)
{
    this->mas = line;
}

QVariant MyModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if (role != Qt::DisplayRole)
    {
        return QVariant();
    }
    if (role == Qt::Horizontal)
    {
        if (section == 0)
        {
            return QVariant("Номер маршрута");
        }
        else
        {
            if (section == 1)
            {
                return QVariant("Конечная остановка");
            }
            else
            {
                if (section == 2)
                {
                    return QVariant("Время в пути");
                }
                else
                {
                    if (section == 3)
                    {
                        return QVariant("Стоимость билета");
                    }
                }
            }
        }
    }
}

int MyModel::rowCount(const QModelIndex &parent) const
{
    //if (parent.isValid())
        return this->mas.size();
    // FIXME: Implement me!
}

int MyModel::columnCount(const QModelIndex &parent) const
{
    //if (parent.isValid())
        return 4;

    // FIXME: Implement me!
}

QVariant MyModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
    {
        return QVariant();
    }
    else
    {
        if (index.column() == 0)
        {
            return QVariant(QString::number(this->mas.at(index.row()).num));
        }
        if (index.column() == 1)
        {
            return QVariant(this->mas.at(index.row()).estop);
        }
        if (index.column() == 2)
        {
            return QVariant((this->mas.at(index.row()).time).toString("hh:mm"));
        }
        if (index.column() == 3)
        {
            return QVariant(QString::number(this->mas.at(index.row()).price));
        }
    }

    // FIXME: Implement me!
    //return QVariant();
}

/*
bool MyModel::removeRow(int row, const QModelIndex &parent)
{
    //beginRemoveRows(-1,-1,(void*)0, 0, 0);
    mas.erase(list.begin()+)
}
*/
