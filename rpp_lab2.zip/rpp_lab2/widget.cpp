#include "widget.h"
#include "ui_widget.h"
#include <QDebug>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    load();
}

void Widget::load()
{
    QFile file ("C:/Users/asus/Desktop/RPP/rpp_lab2/log.txt");
    QByteArray reading;
    QString line;
    if (!file.open(QIODevice::ReadOnly))
    {
        qDebug() << "Файл не открыт";
    }
    else
    {
        QTextStream textStream(&file);

        int num = 0;
        int flag = 0;
        line = textStream.readLine();
        for (int i = 0; i <= line.size(); i++)
        {
            if ((line[i] >= "0")&&(line[i] <= "9"))
            {
                num = num*10 + line[i].digitValue();
            }
            else
            {
                if (flag == 0)
                {
                    ui->tab->setColumnCount(num);
                    flag ++;
                    num = 0;
                }
                else
                {
                    ui->tab->setRowCount(num);
                }
            }
        }

        for (int i = 0; !textStream.atEnd(); i++)
        {
            line = textStream.readLine();
            QString text = "";
            int y = 0;
            for (int j = 0; j < line.size(); j++)
            {
                if (line[j] != " ")
                {
                    text += line[j];
                }
                else
                {
                    QTableWidgetItem *item = new QTableWidgetItem();
                    item->setText(text);
                    ui->tab->setItem(i,y,item);
                    text = "";
                    y++;
                }
            }
            QTableWidgetItem *item = new QTableWidgetItem();
            item->setText(text);
            ui->tab->setItem(i,y,item);
        }
        file.close();
    }
    return;
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_clicked()
{
    close();
}
