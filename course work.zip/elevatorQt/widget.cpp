#include "widget.h"
#include "ui_widget.h"
#include <QLabel>
#include <QDebug>
#include <QPushButton>
#include <QSpinBox>
#include <QLineEdit>
#include <QEventLoop>
#include <QTimer>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    onOff = 0;
    ui->setupUi(this);
    ui->table->setTabText(2, "Назнач.");
    ui->table->setTabText(1, "Вызов");
    ui->table->setTabText(0, "Высота");
    ui->emiting->setEnabled(false);//Начвло работы
    //ui->stop->setEnabled(false);//Конейц работы
    ui->end->setEnabled(true);//Завершение программы
    ui->changeFloor->setEnabled(false);
    ui->verVisitor->setEnabled(false);
    ui->newF->setEnabled(false);
    ui->newH->setEnabled(false);
    ui->changeWay->setEnabled(false);
    ui->verWay->setEnabled(false);
    ui->newW->setEnabled(false);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_end_clicked()
{
    close();
}

void Widget::on_newH_clicked()
{
    int num = 0;
    for (int i = 0; i < ui->numFloor->text().size(); i++)
    {
        num = num * 10 + ui->numFloor->text().at(i).digitValue();
    }
    qDebug() << ui->numFloor->text() << "=" << num;
    this->lift.height = num;
    this->teor.quantity = num;
    this->teor.neighbor.clear();
    this->teor.visitor.clear();
    //this->flag = 1;

    for (int i = 0; i < num; i++)
    {
        this->teor.neighbor.push_back(0);
        vector<int> help;
        for (int j = 0; j < num; j++)
        {
            help.push_back(0);
        }
        this->teor.visitor.push_back(help);
    }
    ui->changeFloor->setEnabled(true);
    ui->verVisitor->setEnabled(true);
    ui->emiting->setEnabled(true);
    //ui->stop->setEnabled(false);

    //ui->numFloor->clear();
    ui->changeFloor->clear();
    ui->verVisitor->clear();
    ui->changeWay->clear();
    ui->verWay->clear();
    return;
}

void Widget::on_newF_clicked()
{
    qDebug() << "Floor "<< ui->changeFloor->text()<< " " << ui->verVisitor->text();
    int a = 0;
    int n = 0;
    for (int i = 0; i < ui->changeFloor->text().size(); i++)
    {
        a = a * 10 + ui->changeFloor->text().at(i).digitValue();
    }
    //qDebug() << "a = " << a;
    for (int i = 0; i < ui->verVisitor->text().size(); i++)
    {
        n = n * 10 + ui->verVisitor->text().at(i).digitValue();
    }
    //qDebug() << "n = " << n;

    //ui->changeFloor->clear();
    ui->verVisitor->clear();
    ui->changeWay->clear();
    ui->verWay->clear();

    if (a <= this->lift.height)
    {
        qDebug() << "toWay " << n;
        teor.neighbor.at(a-1) = n;
        ui->changeWay->setEnabled(true);
        ui->verWay->setEnabled(true);
    }
    return;
}

void Widget::on_newW_clicked()
{
    qDebug() << "Way " << ui->changeFloor->text() << " " << ui->changeWay->text() << " " << ui->verWay->text();
    int a = 0;
    int b = 0;
    int n = 0;
    for (int i = 0; i < ui->changeFloor->text().size(); i++)
    {
        a = a * 10 + ui->changeFloor->text().at(i).digitValue();
    }
    for (int i = 0; i < ui->changeWay->text().size(); i++)
    {
        b = b * 10 + ui->changeWay->text().at(i).digitValue();
    }
    for (int i = 0; i < ui->verWay->text().size(); i++)
    {
        n = n * 10 + ui->verWay->text().at(i).digitValue();
    }
    teor.visitor.at(a-1).at(b-1) = n;

    ui->changeWay->clear();
    ui->verWay->clear();
    return;
}

void Widget::on_numFloor_valueChanged(const QString &arg1)
{
    qDebug() << "change";
    if (ui->numFloor->text().size() > 0)
    {
        int num = 0;
        for (int i = 0; i < ui->numFloor->text().size(); i++)
        {
            num = num * 10 + ui->numFloor->text().at(i).digitValue();
        }
        if (num >= 2)
        {
            ui->newH->setEnabled(true);
        }
        else
        {
            ui->newH->setEnabled(false);
            ui->changeFloor->setEnabled(false);
            ui->verVisitor->setEnabled(false);
            ui->newF->setEnabled(false);
            ui->changeWay->setEnabled(false);
            ui->verWay->setEnabled(false);
            ui->newW->setEnabled(false);
        }
    }
    else
    {
        ui->newH->setEnabled(false);
        ui->changeFloor->setEnabled(false);
        ui->verVisitor->setEnabled(false);
        ui->newF->setEnabled(false);
        ui->changeWay->setEnabled(false);
        ui->verWay->setEnabled(false);
        ui->newW->setEnabled(false);
    }
    return;
}

void Widget::on_changeFloor_valueChanged(int num)
{
    qDebug() << "num (" << num <<") < "<< this->lift.height;
    if ((num > 1)&&(num <= this->lift.height))
    {
        ui->newF->setEnabled(true);
        ui->changeWay->setEnabled(false);
        ui->verWay->setEnabled(false);
        ui->newW->setEnabled(false);
    }
    else
    {
        ui->newF->setEnabled(false);
        //ui->changeWay->setEnabled(false);
        //ui->verWay->setEnabled(false);
        ui->newW->setEnabled(false);
    }
}

/*
void Widget::on_verWay_textChanged(const QString &arg1)
{
    int num = 0;
    for (int i = 0; i < ui->numFloor->text().size(); i++)
    {
        num = num * 10 + ui->numFloor->text().at(i).digitValue();
    }
    qDebug() << "Visior num = " << num << " and size = " << ui->changeFloor->text().size();
    if ((num >= 0)&&(num <= 100)&&(ui->changeFloor->text().size() > 0))
    {
        ui->newF->setEnabled(true);
        ui->changeWay->setEnabled(false);
        ui->verWay->setEnabled(false);
        ui->newW->setEnabled(false);
    }
    else
    {
        ui->newF->setEnabled(false);
        ui->changeWay->setEnabled(false);
        ui->verWay->setEnabled(false);
        ui->newW->setEnabled(false);
    }
}
*/

void Widget::on_verVisitor_textChanged(const QString arg1)
{
    int num = 0;
    for (int i = 0; i < arg1.size(); i++)
    {
        num = num * 10 + arg1.at(i).digitValue();
    }
    qDebug() << "Visior num = " << num << " and size = " << ui->changeFloor->text().size();
    if ((num >= 0)&&(num <= 100)&&(ui->changeFloor->text().size() > 0))
    {
        ui->newF->setEnabled(true);
        ui->changeWay->setEnabled(false);
        ui->verWay->setEnabled(false);
        ui->newW->setEnabled(false);
    }
    else
    {
        ui->newF->setEnabled(false);
        //ui->changeWay->setEnabled(false);
        //ui->verWay->setEnabled(false);
        //ui->newW->setEnabled(false);
    }
}

void Widget::on_changeWay_valueChanged(int num)
{
    //qDebug() << "num (" << num <<") < "<< this->lift.height;
    if ((num > 1)&&(num <= this->lift.height)&&(ui->verWay->text().size() > 0))
    {
        ui->newW->setEnabled(true);
    }
    else
    {
        ui->newW->setEnabled(false);
    }
}

void Widget::on_verWay_textChanged(const QString &arg1)
{
    int num = 0;
    for (int i = 0; i < arg1.size(); i++)
    {
        num = num * 10 + arg1.at(i).digitValue();
    }
    qDebug() << "Visior num = " << num << " and size = " << ui->changeFloor->text().size();
    if ((num >= 0)&&(num <= 100)&&(ui->changeWay->text().size() > 0))
    {
        ui->newW->setEnabled(true);
    }
    else
    {
        ui->newW->setEnabled(false);
    }
}

void Widget::on_emiting_clicked()
{
    for (int i = 0; i < this->onOff; i++)
    {
        qDebug() << "ЦИКЛ";
        adapt();
        QEventLoop loop;
        QTimer timer;
        timer.setInterval(5000); //5 sec
        connect (&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
        timer.start();
        loop.exec();
    }
}

/*
void Widget::on_stop_clicked()
{
    onOff = 0;
    ui->stop->setEnabled(false);
    ui->emiting->setEnabled(true);
}
*/

void Widget::adapt()
{
    int floor;
    int way;
    floor = this->teor.goNeighbor();
    way = this->teor.goVisitor(floor-1);
    ui->wFloor->setText(QString::number(floor));
    ui->wWay->setText(QString::number(way));
    this->lift.newElntLine(floor-1);//добавляем сначала ради вызова -1?
    this->lift.moveLine();
    this->lift.newElntLine(way);
    this->lift.moveLine();

    ui->liftfloor->setText(QString::number(this->lift.nowF));
    qDebug() << "EMIT " << floor << "_" << way;
    return;
}

void Widget::on_stop_2_valueChanged(int num)
{
    this->onOff = num;
}
