#ifndef VEROYT_H
#define VEROYT_H
#include <iostream>
#include <random>
using namespace std;

class Veroyt
{
public:
    vector<int> neighbor;//вероятность вызова лифта
    vector<vector<int>> visitor;//вероятность выбора этажа для каждого вызова
    int quantity;//кол-во этажей

    Veroyt();
    int goNeighbor();//выбор этажа для вызова
    int goVisitor(int floor);//выбор этажа для вызова на этаже floor
};

#endif // VEROYT_H
