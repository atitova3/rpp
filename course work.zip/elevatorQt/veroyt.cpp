#include "veroyt.h"
#include <iostream>
#include <random>
#include <stdlib.h>
#include <math.h>
#include <QDateTime>
#include <QTime>
#include <QDebug>
using namespace std;

Veroyt::Veroyt()
{
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
}

int Veroyt::goNeighbor()
{
    int ver = qrand()%102;
    qDebug() << "ver neigh " << ver;
    qDebug() << "this->qua " << this->quantity;
    int nowver = 0; //текущая вероятность
    for (int i = 0; i < this->quantity; )
    {
        nowver += this->neighbor.at(i);
        if (ver <= nowver)
        {
            qDebug() << "ver = " << ver << " now = " << nowver << " i = "<< i;
            return i+1;
        }
        i++;
    }
}

int Veroyt::goVisitor(int floor)
{
    int ver = qrand()%102;
    int nowver = 0; //текущая вероятность
    for (int i = 0; i < this->quantity; )
    {
        nowver += this->visitor.at(floor).at(i);
        if (ver <= nowver)
        {
            return i+1;
        }
        i++;
    }
}
