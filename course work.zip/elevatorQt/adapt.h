#ifndef ADAPT_H
#define ADAPT_H

#include <QObject>
#include <QString>
#include <elev.h>
#include <veroyt.h>

class Adapt : public QObject
{
    Q_OBJECT
    Elev lift;
    Veroyt teor;
    int flag;//что хотя бы раз здание создали
    int onOff;//эмитировать/прекратить эмитировать
    //int nowF;//текущий этаж по его достижению, если движется
    //int goTo; //-1-движ вниз, 1 - движ вверх, 0 - стоит

public:
    explicit Adapt(QObject *parent = nullptr);
    void emitLift();

signals:
    gofloor(int num);
    goway (int num);
    perLift();

public slots:
    void getOldText(QString text);
    void newHouse(QString floor);
    void newFloor(QString floor, QString ver);
    void newWay(QString floor, QString way, QString ver);
    void working();

    //void liftPers();//принемает сигнал об отрисовке графики
};

#endif // ADAPT_H
