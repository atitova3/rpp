#include "widget.h"
#include <QApplication>
#include <windows.h>
#include <QIcon>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.setWindowIcon(QIcon(":resource/houses.ico"));
    //w.setWindowIconText("Эмитация работы лифта");
    //w.setWindowRole("Эмитация работы лифта");
    w.setWindowTitle("Эмитация работы лифта");
    w.show();

    return a.exec();
}
