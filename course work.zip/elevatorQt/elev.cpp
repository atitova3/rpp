#include "elev.h"
#include <algorithm>
#include <QDebug>
//#define emit

Elev::Elev(QObject *parent) : QObject(parent)
{
    this->nowF = 1;
    this->goTo = 1;//так как стартуем с 1ого этажа то по умолчанию движемся вверх
}

void Elev::moveLine()//изменеие очереди в cвязи с движением
{
    if ((this->line.size() != 0)||((this->line.size() == 1) && (this->line.at(0) == this->nowF)))//если в очереди кто-то есть или вызов не с текущего этажа
    {
        if (goTo == 1)
        {
            this->nowF = this->line.at(0);
            this->line.erase(line.begin());//удаление первого эл-та
            qDebug() << "НОВЫЙ ПЕРВЫЙ " << this->line.at(0);
            /*
            for (int i = 0; i < this->line.size(); i++)
            {
                qDebug() << "Добавка " << this->line.at(i);
            }
            */
        }
        else//goTo == -1
        {
            this->nowF = this->line.at(this->line.size()-1);
            this->line.erase(this->line.end());//удаление последнего эл-та
            qDebug() << "НОВЫЙ ПОСЛЕДНИЙ " << this->line.at(this->line.size()-1);
            //
            for (int i = 0; i < this->line.size(); i++)
            {
                qDebug() << "Добавка " << this->line.at(i);
            }
            //
        }
        //emit paint(this->nowF, this->goTo);
        //this->time += this->tGo;
    }
    return;
}

void Elev::newElntLine(int newFl)
{
    int i = 0;
    int fl = 0;
    while ((i < this->line.size())&&(fl == 0))
    {
        if (newFl == this->line.at(i))
        {
            fl = 1;
        }
        i++;
    }

    if (fl == 0)//если этажа уже нет очереди
    {
        if (this->line.size() == 0)
        {
            if (this->nowF <= newFl)
            {
                this->goTo = 1;
            }
            else
            {
                this->goTo = -1;
            }
        }
        this->line.push_back(newFl);
        //
        for (int i = 0; i < this->line.size(); i++)
        {
            qDebug() << this->nowF << "Изьятие " << this->line.at(i);
        }
        //
        sort(line.begin(), line.end());
    }


}

void Elev::newGoTo(int napr)
{
    this->goTo = napr;
    //нужен ли поворот очереди?
}
