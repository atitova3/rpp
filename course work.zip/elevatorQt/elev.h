#ifndef ELEV_H
#define ELEV_H
#include <vector>
#include <QObject>
using namespace std;

class Elev : public QObject
{
    Q_OBJECT
public:
    int nowF;//текущий этаж по его достижению, если движется
    int goTo; //-1-движ вниз, 1 - движ вверх, 0 - стоит
    vector<int> line;//очередь вызавов
    //int tGo = 3; //время межу этажами
public:
    explicit Elev(QObject *parent = nullptr);
    //Elev();
    //int time = 0; //время работы
    int height;//высота здания

    void moveLine();//изменеие очереди в звязи с движением
    void newElntLine(int newFl); //изменение очереди в связи с новым вызовом + добавляет эл-т в line
    void newGoTo(int napr);//изменяет направление goTo = napr
    /*так как не хочу наследовать от QObject*/
};

#endif // ELEV_H
