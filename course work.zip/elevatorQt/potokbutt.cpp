#include "potokbutt.h"

potokButt::potokButt(int onOff))
{

}

