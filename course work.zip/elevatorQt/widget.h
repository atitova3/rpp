#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <elev.h>
#include <veroyt.h>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT
    Elev lift;
    Veroyt teor;
    int flag;//что хотя бы раз здание создали
    int onOff;//эмитировать/прекратить эмитировать

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    void adapt();

private slots:
    void on_end_clicked();

    void on_newH_clicked();

    void on_newF_clicked();

    void on_newW_clicked();

    void on_numFloor_valueChanged(const QString &arg1);

    void on_changeFloor_valueChanged(int arg1);

    void on_verVisitor_textChanged(const QString arg1);

    void on_changeWay_valueChanged(int arg1);

    void on_verWay_textChanged(const QString &arg1);

    void on_emiting_clicked();

    //void on_stop_clicked();

    void on_stop_2_valueChanged(int arg1);

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
