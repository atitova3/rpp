#include "adapt.h"
#include <QDebug>
#include <random>
#include <math.h>
#include <QDateTime>
#include <QTime>
using namespace std;

Adapt::Adapt(QObject *parent) : QObject(parent)
{
    this->onOff = 1;//эмиторовать
}

void Adapt::getOldText(QString text)
{
    qDebug() << text;
    //qDebug() << qrand() % 101;//вывод процентной вероятности
}

void Adapt::newHouse(QString floor)
{
    int num = 0;
    for (int i = 0; i < floor.size(); i++)
    {
        num = num * 10 + floor.at(i).digitValue();
    }
    qDebug() << floor << "=" << num;
    this->lift.height = num;
    this->teor.quantity = num;
    this->teor.neighbor.clear();
    this->teor.visitor.clear();
    this->flag = 1;
    for (int i = 0; i < num; i++)
    {
        this->teor.neighbor.push_back(0);
        vector<int> help;
        for (int j = 0; j < num; j++)
        {
            help.push_back(0);
        }
        this->teor.visitor.push_back(help);
    }
    return;
}

void Adapt::newFloor(QString floor, QString ver)
{
    qDebug() << "Floor " << floor << " " << ver;
    int a = 0;
    int n = 0;
    for (int i = 0; i < floor.size(); i++)
    {
        a = a * 10 + floor.at(i).digitValue();
    }
    for (int i = 0; i < ver.size(); i++)
    {
        n = n * 10 + ver.at(i).digitValue();
    }
    teor.neighbor.at(a-1) = n;
    return;
}

void Adapt::newWay(QString floor, QString way, QString ver)
{
    qDebug() << "Way " << floor << " " << way << " " << ver;
    int a = 0;
    int b = 0;
    int n = 0;
    for (int i = 0; i < floor.size(); i++)
    {
        a = a * 10 + floor.at(i).digitValue();
    }
    for (int i = 0; i < way.size(); i++)
    {
        b = b * 10 + way.at(i).digitValue();
    }
    for (int i = 0; i < ver.size(); i++)
    {
        n = n * 10 + ver.at(i).digitValue();
    }
    teor.visitor.at(a-1).at(b-1) = n;
    return;
}

void Adapt::working()
{
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    if ((this->flag == 1)&&(this->onOff == 1))//дом слздан хотя бы раз
    {
        qDebug() << "Эмитация работы!";
        this->emitLift();
        this->onOff = 0;//прекращать эмитировать
    }
    if (this->onOff == 0)
    {
        this->emitLift();
        this->onOff = 1;
    }
    return;
}

void Adapt::emitLift()
{
    int floor;
    int way;
    floor = teor.goNeighbor();
    way = teor.goVisitor(floor-1);
    emit gofloor(floor);
    emit goway(way);
    /*
    while (this->onOff == 1)
    {
        floor = teor.goNeighbor();
        way = teor.goVisitor(floor-1);
        QString text = QString::number(floor);
        emit gofloor(QVariant(text));
        text = QString::number(way);
        emit goway(QVariant(text));
    }
    */
    //qDebug() << "1t " << teor.goNeighbor();// << " v " << teor.goVisitor(0);
    //qDebug() << "2t " << teor.goVisitor(0);
    //qDebug() << "3t " << teor.goNeighbor() << " v " << teor.goVisitor(0);
    return;
}
